﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace _13_2
{
    public class Student
    {
        public Student(string name, string surname, int bookname)
        {
            this.name = name;
            this.surname = surname;
            this.bookname = bookname;
        }
        private string name;
        private string surname;
        private int bookname;
        public void SetName(string name)
        {
            this.name = name;
        }
        public string GetName()
        {
            return this.name;
        }
        public void SetSurname(string surname)
        {
            this.surname = surname;
        }
        public string GetSurname()
        {
            return this.surname;
        }
        public void SetBookName(int bookname)
        {
            this.bookname= bookname;
        }
        public int GetBookName()
        {
            return this.bookname;
        }
       
        }
    }
   
  

